<?php

  error_reporting(0);

  $name = utf8_encode($_POST["name"]);
  $email = utf8_encode($_POST["email"]);
  $telephone = utf8_encode($_POST["telephone"]);
  $description = utf8_encode($_POST["description"]);

  require './class.phpmailer.php';

  $mail = new PHPMailer;
  $mail->isSMTP();

  $mail->Host = "ns892.hostgator.com.br";
  $mail->Port = "465";
  $mail->SMTPSecure = "TLS";
  $mail->SMTPAuth = "true";
  $mail->Username = "contato@allcursoonline.com";
  $mail->Password = "598852@oiTB";

  $mail->setFrom($mail->Username, "Confeitaria Lucrativa");
  $mail->addAdress("contato@allcursoonline.com");
  $mail->Sbject = "Fale Conosco";

  $email_message = "
    Contato de $nome:<br>
    Email: $email,<br>
    Telefone: $telephone,<br>
    Mensagem:<br>
    $description
  ";

  $mail->IsHTML(true);
  $mail->Body = $email_message;

  if($mail->send()) {
    echo "Email enviado com sucesso!";
  } else {
    echo "Erro ao enviar email!".$mail->ErrorInfo;
  };


  ?>