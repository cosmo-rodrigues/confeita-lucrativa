<?php

  error_reporting(0);

  $name = utf8_encode($_POST["name"]);
  $email = utf8_encode($_POST["email"]);

  require './class.phpmailer.php';

  $mail = new PHPMailer;
  $mail->isSMTP();

  $mail->Host = "ns892.hostgator.com.br";
  $mail->Port = "465";
  $mail->SMTPSecure = "TLS";
  $mail->SMTPAuth = "true";
  $mail->Username = "contato@allcursoonline.com";
  $mail->Password = "598852@oiTB";

  $mail->setFrom($mail->Username, "Confeitaria Lucrativa");
  $mail->addAdress("contato@allcursoonline.com");
  $mail->Sbject = "Cadastro Newsletter";

  $email_message = "
    Cadastro de $nome:<br>
    Email: $email,<br>
    Contato para newsletter.
  ";

  $mail->IsHTML(true);
  $mail->Body = $email_message;

  if($mail->send()) {
    echo "Cadastro realizado com sucesso!";
  } else {
    echo "Erro ao cadastrar, tente novamente, por favor!".$mail->ErrorInfo;
  };
  
  ?>